const scenes = {
  start: {
    text: `Lu baru pulang kerja malem-malem. Jalan pintas lewat kuburan biar cepet.
Tiba-tiba ada suara kain gesek... DAN sebuah pocong lompat dari balik nisan.`,
    choices: [
      {text: 'Lari sekenceng-kencengnya', to: 'run'},
      {text: 'Pura-pura pingsan', to: 'fake'},
      {text: 'Ngobrol sama pocong', to: 'talk'}
    ]
  },
  talk: {
    text: `Pocong itu diam. Dia nyodorin amplop kotor.
"Gua... gak bisa pulang..." katanya serak.`,
    choices: [
      {text: 'Ambil amplop', to: 'take'},
      {text: 'Tanya isinya', to: 'ask'},
      {text: 'Kabur', to: 'run'}
    ]
  },
  ask: {
    text: `Lu tanya, "Isinya apa?"
Pocong membuka sedikit kain: di dalam ada kertas usang bertuliskan: "HENTIKAN SIKLUSNYA".
Suara tawa samar terdengar di kejauhan.`,
    choices: [
      {text: 'Baca kertasnya', to: 'read'},
      {text: 'Buang dan kabur', to: 'run'},
      {text: 'Tanya lagi', to: 'talkmore'}
    ]
  },
  take: {
    text: `Lu ambil amplop. Tiba-tiba tanah di sekitar nisan retak dan sekelebat bayangan melintas.
Amplop itu hangat. Di belakang lu ada jalan kecil yang nggak keliatan sebelumnya.`,
    choices: [
      {text: 'Ikutin jalan kecil', to: 'path'},
      {text: 'Buka amplop', to: 'read'},
      {text: 'Balikin amplop dan kabur', to: 'run'}
    ]
  },
  read: {
    text: `Di kertas itu ada petunjuk: "Taruh bunga di nisan terakhir, sebut nama, dan jangan pernah menatap mata."`,
    choices: [
      {text: 'Ikutin petunjuk', to: 'ritual'},
      {text: 'Nggak percaya, buru-buru kabur', to: 'run'}
    ]
  },
  ritual: {
    text: `Lu lakuin ritual: taruh bunga, sebut nama pocong (yang ada di kertas), dan menutup mata.
Angin berhenti. Pocong bilang, "Makasih..." lalu melayang pergi. Lo selamat, tapi ada satu pesan: "Jaga pintu itu."`,
    choices: [
      {text: 'Selesai — selamat', to: 'ending_good'},
      {text: 'Intip pintu yang dia maksud', to: 'door'}
    ]
  },
  door: {
    text: `Di balik pohon ada pintu tua. Kalo dibuka, suara-suara dari lain alam bisa masuk.
Lu ngerasa tugas lu baru mulai.`,
    choices: [
      {text: 'Buka pintu (berani)', to: 'ending_open'},
      {text: 'Tutup dan pergi', to: 'ending_good'}
    ]
  },
  path: {
    text: `Jalan kecil itu nuntun lu ke sebuah gubuk tua. Di jendela ada lilin menyala.
Suasana makin aneh.`,
    choices: [
      {text: 'Masuk gubuk', to: 'hut'},
      {text: 'Tinggalin amplop dan lari', to: 'run'}
    ]
  },
  hut: {
    text: `Di dalam ada altar kecil. Foto-foto orang yang nggak pernah lu kenal.
Satu foto ada coretan nama lu sendiri.`,
    choices: [
      {text: 'Lihat lebih dekat', to: 'ending_bad'},
      {text: 'Lari keluar', to: 'run'}
    ]
  },
  fake: {
    text: `Lu pura-pura pingsan. Pocong itu nangis, lalu bilang: "Tolong..."
Ketika lu buka mata, ada luka kecil di tangan lu.`,
    choices: [
      {text: 'Periksa tangan', to: 'wound'},
      {text: 'Tegaskan buat bangun', to: 'talk'}
    ]
  },
  wound: {
    text: `Lukanya aneh: kaya kain putih nempel di kulit. Lu ngerasa ada yang nempel di hati.`,
    choices: [
      {text: 'Lepas kain (berisiko)', to: 'ending_bad'},
      {text: 'Biarkan dan bantu pocong', to: 'ritual'}
    ]
  },
  run: {
    text: `Lu lari. Kuburan makin like maze. Suara langkah mengikuti dari belakang.`,
    choices: [
      {text: 'Terus lari', to: 'ending_bad'},
      {text: 'Sembunyi di balik nisan', to: 'hide'}
    ]
  },
  hide: {
    text: `Lu sembunyi. Pocong lewat cuma beberapa cm dari muka lu. Dia nunjukin mulutnya yang kosong.`,
    choices: [
      {text: 'Tetap diem', to: 'ending_good'},
      {text: 'Tantang pocong', to: 'ending_bad'}
    ]
  },
  ending_good: {text: `LU SELAMAT. Tapi malem itu lu ngerasa ada yang berubah — lo jadi penjaga rahasia kuburan. (ENDING BAIK)`, choices: []},
  ending_bad: {text: `LU KEMATIAN. Sesuatu narik lu ke dalam bumi dan gelap selamanya. (ENDING BURUK)`, choices: []},
  ending_open: {text: `LU BUKA PINTU. Kalian berdua... bukan cuma lu lagi yang ngerti dunia itu. (ENDING AMBIGU)`, choices: []}
}

let current = 'start'

function render() {
  const scene = scenes[current]
  const sceneEl = document.getElementById('scene')
  const choicesEl = document.getElementById('choices')
  sceneEl.textContent = scene.text
  choicesEl.innerHTML = ''
  if (!scene.choices || scene.choices.length === 0) {
    const btn = document.createElement('div')
    btn.className = 'choice'
    btn.textContent = 'Kembali ke awal'
    btn.addEventListener('click', ()=>{ current='start'; render(); })
    choicesEl.appendChild(btn)
    return
  }
  scene.choices.forEach(c=>{
    const el = document.createElement('div')
    el.className = 'choice'
    el.textContent = c.text
    el.addEventListener('click', ()=>{
      current = c.to
      render()
    })
    choicesEl.appendChild(el)
  })
}

render()

document.getElementById('saveBtn').addEventListener('click', ()=>{
  localStorage.setItem('pocong_save', current)
  alert('Game disimpan!')
})
document.getElementById('loadBtn').addEventListener('click', ()=>{
  const s = localStorage.getItem('pocong_save')
  if (s) { current = s; render(); alert('Muat berhasil') } else alert('Tidak ada save')
})
document.getElementById('restartBtn').addEventListener('click', ()=>{
  current='start'; render();
})
