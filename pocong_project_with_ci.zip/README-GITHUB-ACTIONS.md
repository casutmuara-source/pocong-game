POCONG - Build APK via GitHub Actions
=====================================

This repository includes a GitHub Actions workflow that attempts to build an Android APK
on push to the `main` or `master` branch or via manual dispatch.

How to use:
1. Create a new GitHub repository and push the contents of this project to it.
2. In the repo settings -> Actions, enable GitHub Actions if prompted.
3. Push to `main` (or `master`) or run "Run workflow" from the Actions tab.
4. Wait for the workflow to finish. The APK artifact will be available under the workflow run's
   "Artifacts" section as `pocong-apk`.

Notes & caveats:
- This workflow installs `gradle` from apt; the build may download dependencies and take some time.
- If the build fails due to missing gradle wrapper or SDK mismatch, consider adding the Gradle wrapper
  (run `gradle wrapper` locally and commit the generated files) or adjust `build.gradle`.
- For a release-signed APK, you'll need to provide a keystore and modify the Gradle `signingConfigs`.
